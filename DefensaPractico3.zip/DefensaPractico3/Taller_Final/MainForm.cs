using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace Taller_Final
{
    public partial class MainForm : Form
    {
        Grafo grafo;
        TablaHash tablaHash;
        MinHeap minHeap;

        private Dictionary<string, Color> colorNodos;
        private HashSet<(string, string)> aristasActivas;

        // colores de los nodos
        private readonly Color ColorDefault  = Color.FromArgb(66, 133, 244);
        private readonly Color ColorOrigen   = Color.FromArgb(211, 47, 47);
        private readonly Color ColorDestino  = Color.FromArgb(46, 125, 50);
        private readonly Color ColorVisitado = Color.FromArgb(245, 124, 0);
        private readonly Color ColorCamino   = Color.FromArgb(56, 142, 60);

        // colores de aristas
        private readonly Color ColorArista    = Color.FromArgb(189, 189, 189);
        private readonly Color ColorAristaAct = Color.FromArgb(56, 142, 60);

        private const int R = 22;

        public MainForm()
        {
            InitializeComponent();

            grafo      = new Grafo();
            tablaHash  = new TablaHash();
            minHeap    = new MinHeap();
            colorNodos = new Dictionary<string, Color>();
            aristasActivas = new HashSet<(string, string)>();

            CargarCampus();
            LlenarCombos();
            ResetColores();

            // aplicar colores a botones
            btnMostrar.BackColor   = Color.FromArgb(30, 136, 229);
            btnMostrar.ForeColor   = Color.White;
            btnBFS.BackColor       = Color.FromArgb(211, 47, 47);
            btnBFS.ForeColor       = Color.White;
            btnDFS.BackColor       = Color.FromArgb(46, 125, 50);
            btnDFS.ForeColor       = Color.White;
            btnHash.BackColor      = Color.FromArgb(123, 31, 162);
            btnHash.ForeColor      = Color.White;
            btnHeap.BackColor      = Color.FromArgb(230, 81, 0);
            btnHeap.ForeColor      = Color.White;
            btnReiniciar.BackColor = Color.FromArgb(84, 84, 84);
            btnReiniciar.ForeColor = Color.White;
        }

        private void CargarCampus()
        {
            grafo.AgregarEdificio("A", "Biblioteca Central");
            grafo.AgregarEdificio("B", "Cafetería");
            grafo.AgregarEdificio("C", "Laboratorio de Cómputo");
            grafo.AgregarEdificio("D", "Rectoría");
            grafo.AgregarEdificio("E", "Gimnasio");
            grafo.AgregarEdificio("F", "Aulas Generales");
            grafo.AgregarEdificio("G", "Estacionamiento");

            grafo.AgregarCamino("A", "B", 120);
            grafo.AgregarCamino("A", "C", 200);
            grafo.AgregarCamino("B", "D", 150);
            grafo.AgregarCamino("B", "E", 300);
            grafo.AgregarCamino("C", "F", 100);
            grafo.AgregarCamino("D", "F", 80);
            grafo.AgregarCamino("E", "G", 250);
            grafo.AgregarCamino("F", "G", 180);
        }

        private void LlenarCombos()
        {
            cmbOrigen.Items.Clear();
            cmbDestino.Items.Clear();
            foreach (string id in grafo.ObtenerIds())
            {
                string etiqueta = $"{id} — {grafo.ObtenerNombre(id)}";
                cmbOrigen.Items.Add(etiqueta);
                cmbDestino.Items.Add(etiqueta);
            }
            cmbOrigen.SelectedIndex  = 0;
            cmbDestino.SelectedIndex = 6;
        }

        private void MostrarResultados(List<string> lineas)
        {
            Resultados.Items.Clear();
            foreach (string l in lineas)
                Resultados.Items.Add(l);
        }

        private void ResetColores()
        {
            foreach (string id in grafo.ObtenerIds())
                colorNodos[id] = ColorDefault;
            aristasActivas.Clear();
            Panel_Grafo.Refresh();
        }

        private string IdSeleccionado(ComboBox cmb) =>
            cmb.SelectedItem?.ToString()?.Substring(0, 1) ?? "A";

        // --- TAREA 1 ---
        private void btnMostrar_Click(object sender, EventArgs e)
        {
            ResetColores();
            MostrarResultados(grafo.MostrarGrafo());
        }

        // --- TAREA 2: BFS ---
        private void btnBFS_Click(object sender, EventArgs e)
        {
            ResetColores();
            tablaHash.Limpiar();

            string inicio = IdSeleccionado(cmbOrigen);
            SetNodoColor(inicio, ColorOrigen);

            var cola      = new Queue<string>();
            var visitados = new HashSet<string>();

            cola.Enqueue(inicio);
            visitados.Add(inicio);

            while (cola.Count > 0)
            {
                string actual = cola.Dequeue();
                tablaHash.RegistrarVisita(grafo.ObtenerNombre(actual));

                if (actual != inicio)
                    SetNodoColor(actual, ColorVisitado);

                foreach (var (dest, _) in grafo.ObtenerVecinos(actual))
                {
                    if (!visitados.Contains(dest))
                    {
                        visitados.Add(dest);
                        cola.Enqueue(dest);
                        SetAristaActiva(actual, dest);
                    }
                }
            }

            MostrarResultados(grafo.BFS(inicio));
        }

        // --- TAREA 3: DFS ---
        private void btnDFS_Click(object sender, EventArgs e)
        {
            ResetColores();
            tablaHash.Limpiar();

            string inicio  = IdSeleccionado(cmbOrigen);
            string destino = IdSeleccionado(cmbDestino);

            SetNodoColor(inicio,  ColorOrigen);
            SetNodoColor(destino, ColorDestino);

            var pila      = new Stack<(string nodo, List<string> camino)>();
            var visitados = new HashSet<string>();
            List<string> caminoFinal = null;

            pila.Push((inicio, new List<string> { inicio }));

            while (pila.Count > 0)
            {
                var (actual, camino) = pila.Pop();
                if (visitados.Contains(actual)) continue;
                visitados.Add(actual);

                tablaHash.RegistrarVisita(grafo.ObtenerNombre(actual));

                if (actual == destino)
                {
                    caminoFinal = camino;
                    break;
                }

                foreach (var (dest, _) in grafo.ObtenerVecinos(actual))
                    if (!visitados.Contains(dest))
                        pila.Push((dest, new List<string>(camino) { dest }));
            }

            if (caminoFinal != null)
            {
                for (int i = 0; i < caminoFinal.Count - 1; i++)
                    SetAristaActiva(caminoFinal[i], caminoFinal[i + 1]);

                foreach (string id in caminoFinal)
                    SetNodoColor(id, ColorCamino);

                SetNodoColor(inicio,  ColorOrigen);
                SetNodoColor(destino, ColorDestino);
            }

            MostrarResultados(grafo.DFS(inicio, destino));
        }

        // --- TAREA 4: Tabla Hash ---
        private void btnHash_Click(object sender, EventArgs e)
        {
            if (tablaHash.ObtenerTodas().Count == 0)
            {
                MostrarResultados(new List<string>
                {
                    "Ejecute BFS o DFS primero para registrar visitas."
                });
                return;
            }

            var lineas = tablaHash.MostrarEstadisticas()
                .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .ToList();
            MostrarResultados(lineas);
        }

        // --- TAREA 5: Min-Heap ---
        private void btnHeap_Click(object sender, EventArgs e)
        {
            ResetColores();
            minHeap.Limpiar();

            foreach (string id in grafo.ObtenerIds())
            {
                foreach (var (dest, dist) in grafo.ObtenerVecinos(id))
                {
                    if (string.Compare(id, dest) < 0)
                        minHeap.Insertar(grafo.ObtenerNombre(id), grafo.ObtenerNombre(dest), dist);
                }
            }

            var lineas = minHeap.MostrarRutasOrdenadas()
                .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .ToList();
            MostrarResultados(lineas);
        }

        // --- Reiniciar ---
        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            tablaHash.Limpiar();
            minHeap.Limpiar();
            Resultados.Items.Clear();
            ResetColores();
            Resultados.Items.Add("Selecciona una operación para comenzar.");
        }

        // --- Dibujado del mapa ---
        private void Panel_Grafo_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int W = Panel_Grafo.Width;
            int H = Panel_Grafo.Height;

            var pos = Grafo.Posiciones();

            PointF Px(string id)
            {
                var (rx, ry) = pos[id];
                return new PointF(rx * W, ry * H);
            }

            var caminos = new List<(string, string, int)>
            {
                ("A","B",120),("A","C",200),("B","D",150),("B","E",300),
                ("C","F",100),("D","F", 80),("E","G",250),("F","G",180),
            };

            // dibujar aristas
            using (var fontPeq = new Font("Segoe UI", 7.5f))
            {
                foreach (var (o, d, w) in caminos)
                {
                    PointF pO = Px(o), pD = Px(d);
                    bool activa = aristasActivas.Contains((o, d)) || aristasActivas.Contains((d, o));

                    using (var pen = new Pen(activa ? ColorAristaAct : ColorArista, activa ? 2.5f : 1.2f))
                        g.DrawLine(pen, pO, pD);

                    float mx = (pO.X + pD.X) / 2f;
                    float my = (pO.Y + pD.Y) / 2f;
                    string lbl = $"{w}m";
                    SizeF sz = g.MeasureString(lbl, fontPeq);
                    g.DrawString(lbl, fontPeq, Brushes.DimGray, mx - sz.Width / 2f, my - sz.Height - 2f);
                }
            }

            // dibujar nodos
            using (var fontId  = new Font("Segoe UI", 10f, FontStyle.Bold))
            using (var fontNom = new Font("Segoe UI", 7f))
            {
                foreach (string id in grafo.ObtenerIds())
                {
                    PointF p   = Px(id);
                    Color  col = colorNodos.ContainsKey(id) ? colorNodos[id] : ColorDefault;

                    using (var brS = new SolidBrush(Color.FromArgb(40, 0, 0, 0)))
                        g.FillEllipse(brS, p.X - R + 2, p.Y - R + 2, R * 2, R * 2);

                    using (var br = new SolidBrush(col))
                        g.FillEllipse(br, p.X - R, p.Y - R, R * 2, R * 2);

                    using (var pen = new Pen(Color.White, 2.5f))
                        g.DrawEllipse(pen, p.X - R, p.Y - R, R * 2, R * 2);

                    SizeF szId = g.MeasureString(id, fontId);
                    g.DrawString(id, fontId, Brushes.White, p.X - szId.Width / 2f, p.Y - szId.Height / 2f);

                    string nom   = grafo.ObtenerNombre(id);
                    SizeF  szNom = g.MeasureString(nom, fontNom);
                    bool   abajo = id == "B" || id == "E";
                    float  yNom  = abajo ? p.Y + R + 3 : p.Y - R - szNom.Height - 2;
                    g.DrawString(nom, fontNom, Brushes.DimGray, p.X - szNom.Width / 2f, yNom);
                }
            }
        }

        private void SetNodoColor(string id, Color c)
        {
            colorNodos[id] = c;
            Panel_Grafo.Refresh();
            Application.DoEvents();
            Thread.Sleep(300);
        }

        private void SetAristaActiva(string o, string d)
        {
            aristasActivas.Add((o, d));
            Panel_Grafo.Refresh();
            Application.DoEvents();
            Thread.Sleep(200);
        }
    }
}
