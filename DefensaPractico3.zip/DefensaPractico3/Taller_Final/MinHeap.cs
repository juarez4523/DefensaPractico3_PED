﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taller_Final
{
        
        public class NodoRuta
        {
            public string Origen { get; set; }
            public string Destino { get; set; }
            public int Distancia { get; set; }

            public NodoRuta(string origen, string destino, int distancia)
            {
                Origen = origen;
                Destino = destino;
                Distancia = distancia;
            }
        }

       
        public class MinHeap
        {
            private List<NodoRuta> heap;

            public MinHeap()
            {
                heap = new List<NodoRuta>();
            }

            public int Tamano => heap.Count;

         
            public bool EstaVacio() => heap.Count == 0;

            private int Padre(int i) => (i - 1) / 2;
            private int HijoIzq(int i) => 2 * i + 1;
            private int HijoDer(int i) => 2 * i + 2;

            private void Intercambiar(int i, int j)
            {
                var tmp = heap[i];
                heap[i] = heap[j];
                heap[j] = tmp;
            }

            
            private void SubirBurbuja(int i)
            {
                while (i > 0 && heap[i].Distancia < heap[Padre(i)].Distancia)
                {
                    Intercambiar(i, Padre(i));
                    i = Padre(i);
                }
            }

            
            private void BajarBurbuja(int i)
            {
                int n = heap.Count;
                while (true)
                {
                    int menor = i;
                    int izq = HijoIzq(i);
                    int der = HijoDer(i);

                    if (izq < n && heap[izq].Distancia < heap[menor].Distancia)
                        menor = izq;
                    if (der < n && heap[der].Distancia < heap[menor].Distancia)
                        menor = der;

                    if (menor == i) break;

                    Intercambiar(i, menor);
                    i = menor;
                }
            }

            
            public void Insertar(string origen, string destino, int distancia)
            {
                heap.Add(new NodoRuta(origen, destino, distancia));
                SubirBurbuja(heap.Count - 1);
            }

            
            public NodoRuta ExtraerMinimo()
            {
                if (EstaVacio())
                    throw new InvalidOperationException("El heap está vacío.");

                NodoRuta minimo = heap[0];

                // Mueve el último al inicio y baja
                heap[0] = heap[heap.Count - 1];
                heap.RemoveAt(heap.Count - 1);

                if (!EstaVacio())
                    BajarBurbuja(0);

                return minimo;
            }

            
            public string MostrarRutasOrdenadas(string nombreOrigen = "")
            {
                var sb = new StringBuilder();
                string encabezado = string.IsNullOrEmpty(nombreOrigen)
                    ? "=== RUTAS ORDENADAS POR DISTANCIA ==="
                    : $"=== RUTAS DESDE {nombreOrigen} — Ordenadas por distancia ===";
                sb.AppendLine(encabezado);

                // Copia temporal para no destruir el heap original
                var copia = new MinHeap();
                foreach (var nodo in heap)
                    copia.Insertar(nodo.Origen, nodo.Destino, nodo.Distancia);

                int posicion = 1;
                while (!copia.EstaVacio())
                {
                    var nodo = copia.ExtraerMinimo();
                    sb.AppendLine($"  {posicion}°  {nodo.Origen} → {nodo.Destino,-22} {nodo.Distancia,4} metros");
                    posicion++;
                }

                sb.AppendLine($"\n  Total de rutas: {posicion - 1}");
                sb.AppendLine("  Heap vacío — todas las rutas fueron procesadas.");
                return sb.ToString();
            }

            public List<NodoRuta> ObtenerNodos() => new List<NodoRuta>(heap);

            public void Limpiar() => heap.Clear();
        }
    }
    


