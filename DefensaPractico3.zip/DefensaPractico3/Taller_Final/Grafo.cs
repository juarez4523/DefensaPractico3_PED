﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taller_Final
{
    public class Grafo
    {
        private Dictionary<string, List<(string destino, int distancia)>> lista;
        private Dictionary<string, string> nombres;

        public Grafo()
        {
            lista = new Dictionary<string, List<(string, int)>>();
            nombres = new Dictionary<string, string>();
        }

        // Tarea 1 

        public void AgregarEdificio(string id, string nombre)
        {
            if (!lista.ContainsKey(id))
            {
                lista[id] = new List<(string, int)>();
                nombres[id] = nombre;
            }
        }

        public void AgregarCamino(string origen, string destino, int distancia)
        {
            if (!lista.ContainsKey(origen) || !lista.ContainsKey(destino)) return;
            lista[origen].Add((destino, distancia));
            lista[destino].Add((origen, distancia));
        }

        public List<string> MostrarGrafo()
        {
            var lineas = new List<string>();
            lineas.Add("=== MAPA DEL CAMPUS ===");
            lineas.Add("");
            foreach (var nodo in lista)
            {
                string id = nodo.Key;
                string linea = $"{nombres[id]} ({id}):";
                foreach (var v in nodo.Value)
                    linea += $"  → {nombres[v.destino]} ({v.destino}) [{v.distancia}m]";
                lineas.Add(linea);
            }
            return lineas;
        }

        // Tarea 2 

        public List<string> BFS(string inicioId)
        {
            var lineas = new List<string>();
            var cola = new Queue<string>();
            var visitados = new HashSet<string>();
            var niveles = new Dictionary<string, int>();
            var porNivel = new Dictionary<int, List<string>>();

            lineas.Add($"=== RECORRIDO BFS desde: {nombres[inicioId]} ({inicioId}) ===");
            lineas.Add("");

            cola.Enqueue(inicioId);
            visitados.Add(inicioId);
            niveles[inicioId] = 0;
            porNivel[0] = new List<string> { inicioId };

            while (cola.Count > 0)
            {
                string actual = cola.Dequeue();
                int nivel = niveles[actual];

                foreach (var (dest, _) in lista[actual])
                {
                    if (!visitados.Contains(dest))
                    {
                        visitados.Add(dest);
                        niveles[dest] = nivel + 1;
                        cola.Enqueue(dest);

                        if (!porNivel.ContainsKey(nivel + 1))
                            porNivel[nivel + 1] = new List<string>();
                        porNivel[nivel + 1].Add(dest);
                    }
                }
            }

            foreach (var kv in porNivel.OrderBy(x => x.Key))
            {
                string nods = string.Join(" | ", kv.Value.Select(id => $"{nombres[id]} ({id})"));
                lineas.Add($"Nivel {kv.Key}:  {nods}");
            }

            lineas.Add("");
            lineas.Add($"Total de edificios visitados: {visitados.Count}");
            return lineas;
        }

        // Tarea 3

        public List<string> DFS(string inicioId, string destinoId)
        {
            var lineas = new List<string>();
            var pila = new Stack<(string nodo, List<string> camino)>();
            var visitados = new HashSet<string>();

            lineas.Add($"=== DFS: {nombres[inicioId]} ({inicioId}) ──► {nombres[destinoId]} ({destinoId}) ===");
            lineas.Add("");

            pila.Push((inicioId, new List<string> { inicioId }));

            while (pila.Count > 0)
            {
                var (actual, camino) = pila.Pop();
                if (visitados.Contains(actual)) continue;
                visitados.Add(actual);

                lineas.Add($"   Visitando: {nombres[actual]} ({actual})");

                if (actual == destinoId)
                {
                    int dist = CalcularDistancia(camino);
                    lineas.Add("");
                    lineas.Add("✔ Camino encontrado:");
                    lineas.Add("   " + string.Join(" → ", camino));
                    lineas.Add($"   Distancia total: {dist} metros");
                    return lineas;
                }

                foreach (var (dest, _) in lista[actual])
                    if (!visitados.Contains(dest))
                        pila.Push((dest, new List<string>(camino) { dest }));
            }

            lineas.Add("");
            lineas.Add($"✘ No existe camino de {nombres[inicioId]} a {nombres[destinoId]}.");
            return lineas;
        }


        private int CalcularDistancia(List<string> camino)
        {
            int total = 0;
            for (int i = 0; i < camino.Count - 1; i++)
            {
                var arista = lista[camino[i]].FirstOrDefault(v => v.destino == camino[i + 1]);
                total += arista.distancia;
            }
            return total;
        }

        public List<string> ObtenerIds() => lista.Keys.ToList();
        public string ObtenerNombre(string id) => nombres.ContainsKey(id) ? nombres[id] : id;
        public List<(string destino, int distancia)> ObtenerVecinos(string id) => lista.ContainsKey(id) ? lista[id] : new List<(string, int)>();

        // Posiciones relativas (0-1) para dibujar los nodos en el panel
        public static Dictionary<string, (float x, float y)> Posiciones() =>
            new Dictionary<string, (float, float)>
            {
                { "A", (0.10f, 0.50f) },
                { "B", (0.35f, 0.50f) },
                { "C", (0.18f, 0.15f) },
                { "D", (0.60f, 0.50f) },
                { "E", (0.35f, 0.82f) },
                { "F", (0.45f, 0.15f) },
                { "G", (0.85f, 0.50f) },
            };
    }
}

