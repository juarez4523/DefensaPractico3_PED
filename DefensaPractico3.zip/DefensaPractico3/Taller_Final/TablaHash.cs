﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taller_Final
{
 
        public class TablaHash
        {
            private Dictionary<string, int> visitas;

            public TablaHash()
            {
                visitas = new Dictionary<string, int>();
            }

            public void RegistrarVisita(string edificio)
            {
                if (visitas.ContainsKey(edificio))
                    visitas[edificio]++;
                else
                    visitas[edificio] = 1;
            }

            public int ObtenerConteo(string edificio)
            {
                return visitas.TryGetValue(edificio, out int count) ? count : 0;
            }

            public string EdificioMasVisitado()
            {
                if (visitas.Count == 0) return "Ninguno";
                return visitas.OrderByDescending(kv => kv.Value).First().Key;
            }

          
            public string MostrarEstadisticas()
            {
                var sb = new StringBuilder();
                sb.AppendLine(" ESTADÍSTICAS DE VISITAS ");

                if (visitas.Count == 0)
                {
                    sb.AppendLine("  No hay visitas registradas.");
                    return sb.ToString();
                }

                int maxVisitas = visitas.Values.Max();
                var ordenado = visitas.OrderByDescending(kv => kv.Value).ToList();

                foreach (var par in ordenado)
                {
                    int bloques = (int)Math.Round((double)par.Value / maxVisitas * 10);
                    string barra = new string('█', bloques);
                    sb.AppendLine($"  {par.Key,-28}: {barra,-12} {par.Value} visita{(par.Value != 1 ? "s" : "")}");
                }

                string masVisitado = EdificioMasVisitado();
                sb.AppendLine($"\n  Edificio más visitado: {masVisitado} con {visitas[masVisitado]} visitas");
                return sb.ToString();
            }

            public Dictionary<string, int> ObtenerTodas() => new Dictionary<string, int>(visitas);

            public void Limpiar() => visitas.Clear();
        }
    }
    

